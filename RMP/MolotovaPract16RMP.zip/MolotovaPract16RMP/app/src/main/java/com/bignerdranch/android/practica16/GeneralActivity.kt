package com.bignerdranch.android.practica16

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class GeneralActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_general)
    }

    fun onButtonClick(view: View) {}

    fun alarm(view: View) {
        var intent = Intent(this,AlarmActivity::class.java)
        startActivity(intent)
    }
    fun calendar(view: View) {
        var intent = Intent(this,CalendarActivity::class.java)
        startActivity(intent)
    }
    fun setting(view: View) {
        var intent = Intent(this,SettingActivity::class.java)
        startActivity(intent)
    }
}