package com.bignerdranch.android.practica16

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class SettingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)
    }

    fun list(view: View) {
        var intent = Intent(this,GeneralActivity::class.java)
        startActivity(intent)
    }
    fun calendar(view: View) {
        var intent = Intent(this,CalendarActivity::class.java)
        startActivity(intent)
    }

    fun alarm(view: View) {
        var intent = Intent(this,AlarmActivity::class.java)
        startActivity(intent)
    }
}