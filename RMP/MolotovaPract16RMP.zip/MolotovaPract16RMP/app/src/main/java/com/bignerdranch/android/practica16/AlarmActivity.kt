package com.bignerdranch.android.practica16

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class AlarmActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm)
    }




    fun setting(view: View) {
        var intent = Intent(this,SettingActivity::class.java)
        startActivity(intent)
    }

    fun list(view: View) {
        var intent = Intent(this,GeneralActivity::class.java)
        startActivity(intent)
    }

    fun calendar(view: View) {
        var intent = Intent(this,CalendarActivity::class.java)
        startActivity(intent)
    }
}